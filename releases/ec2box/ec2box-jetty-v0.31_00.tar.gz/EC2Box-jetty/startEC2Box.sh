#!/bin/bash

cd jetty;

java -Xms1024m -Xmx1024m -jar start.jar 
